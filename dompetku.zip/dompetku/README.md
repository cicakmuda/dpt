# Dompetku — aplikasi pencatat keuangan (PWA + Google Sheets)

Isi paket:

- `backend/Code.gs` — tempel di spreadsheet: Ekstensi → Apps Script. JANGAN diunggah ke GitHub.
- `app/` — unggah SEMUA ISI folder ini ke GitHub Pages (index.html harus paling atas di repositori).

Urutan setup singkat:

1. Apps Script: tempel Code.gs → Simpan → jalankan `setup` → izinkan → catat Kunci Akses dari log.
2. Terapkan → Deployment baru → Aplikasi web (Jalankan sebagai: Saya, Akses: Siapa saja) → salin URL /exec.
3. GitHub: repositori publik `dompetku` → unggah isi folder `app` → Settings → Pages → branch main, root.
4. Buka alamat Pages di HP → tempel URL + Kunci Akses → Hubungkan → Tambahkan ke Layar Utama.

Panduan lengkap & checklist pengujian ada di dokumen panduan yang menyertai paket ini.
