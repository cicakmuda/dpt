/**
 * ==================================================================
 *  DOMPETKU — Backend Google Apps Script            (file: Code.gs)
 *  Versi 1.0.0
 *
 *  Penghubung aman antara aplikasi Dompetku di HP dan spreadsheet-mu.
 *
 *  CARA PASANG (ringkas — panduan lengkap ada di dokumen setup):
 *   1. Buka spreadsheet → menu Ekstensi → Apps Script.
 *   2. Hapus isi Code.gs bawaan, tempel SELURUH isi file ini, Simpan.
 *   3. Pilih fungsi "setup" di toolbar → klik ▶ Jalankan → izinkan akses.
 *   4. Deploy → Deployment baru → jenis "Aplikasi web":
 *        - Jalankan sebagai      : Saya (akunmu)
 *        - Yang memiliki akses   : Siapa saja
 *   5. Salin URL Web App + Kunci Akses (menu 💰 Dompetku → Lihat kunci akses)
 *      lalu masukkan ke aplikasi di HP.
 *
 *  KEAMANAN: setiap permintaan wajib membawa Kunci Akses rahasia
 *  (±120-bit acak). Tanpa kunci yang benar, tidak ada data yang bisa
 *  dibaca atau diubah. Jangan bagikan kunci ini ke siapa pun.
 *
 *  PRINSIP DATA:
 *   - Tidak pernah menimpa / mengubah data lama, kecuali baris yang
 *     kamu edit sendiri dari aplikasi.
 *   - Transaksi yang dihapus dipindah ke sheet "Arsip" (bisa dipulihkan).
 *   - Kolom dikenali otomatis dari judul kolom (header) yang sudah ada.
 * ==================================================================
 */

const APP = { name: 'Dompetku', version: '1.0.0' };

const SHEETS = {
  pemasukan: 'Pemasukan',
  pengeluaran: 'Pengeluaran',
  arsip: 'Arsip',
  kategori: 'Kategori'
};

/** Kolom yang dipakai aplikasi + nama-nama header yang dikenali (huruf kecil). */
const FIELDS = ['tanggal', 'kategori', 'nominal', 'catatan', 'metode', 'id'];
const LABELS = { tanggal: 'Tanggal', kategori: 'Kategori', nominal: 'Nominal', catatan: 'Catatan', metode: 'Metode', id: 'ID' };
const ALIASES = {
  tanggal:  ['tanggal', 'tgl', 'date', 'tanggal transaksi', 'hari tanggal', 'waktu'],
  kategori: ['kategori', 'category', 'pos', 'jenis', 'sumber', 'kelompok'],
  nominal:  ['nominal', 'jumlah', 'amount', 'nilai', 'total', 'harga', 'biaya', 'uang', 'rupiah', 'rp'],
  catatan:  ['catatan', 'keterangan', 'deskripsi', 'description', 'note', 'notes', 'ket', 'uraian', 'detail', 'memo'],
  metode:   ['metode', 'metode pembayaran', 'pembayaran', 'akun', 'sumber dana', 'rekening', 'dompet', 'payment', 'via'],
  id:       ['id', 'id transaksi', 'transaction id']
};

/** Kategori bawaan (dipakai saat sheet "Kategori" dibuat pertama kali). */
const DEFAULT_CATEGORIES = [
  ['Pengeluaran', 'Makan & Minum', '🍜'], ['Pengeluaran', 'Belanja Harian', '🛒'],
  ['Pengeluaran', 'Transportasi', '🚗'], ['Pengeluaran', 'Tagihan & Utilitas', '💡'],
  ['Pengeluaran', 'Tempat Tinggal', '🏠'], ['Pengeluaran', 'Kesehatan', '💊'],
  ['Pengeluaran', 'Pendidikan', '📚'], ['Pengeluaran', 'Hiburan', '🎬'],
  ['Pengeluaran', 'Belanja Pribadi', '🛍️'], ['Pengeluaran', 'Langganan', '📱'],
  ['Pengeluaran', 'Keluarga', '👨‍👩‍👧'], ['Pengeluaran', 'Sedekah & Donasi', '🤲'],
  ['Pengeluaran', 'Cicilan & Utang', '💳'], ['Pengeluaran', 'Lainnya', '📦'],
  ['Pemasukan', 'Gaji', '💼'], ['Pemasukan', 'Bonus', '🎁'], ['Pemasukan', 'Usaha', '🏪'],
  ['Pemasukan', 'Freelance', '💻'], ['Pemasukan', 'Investasi', '📈'], ['Pemasukan', 'Hadiah', '🎉'],
  ['Pemasukan', 'Cashback & Refund', '↩️'], ['Pemasukan', 'Lainnya', '💰'],
  ['Metode', 'Tunai', '💵'], ['Metode', 'Bank', '🏦'], ['Metode', 'E-Wallet', '📲'], ['Metode', 'Kartu Kredit', '💳']
];

class AppError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

/* ================================================================
 *  ENTRY POINTS
 * ================================================================ */

function doGet() {
  return json_({ ok: true, data: { app: APP.name, version: APP.version, message: 'API Dompetku aktif. Buka aplikasi Dompetku untuk mengakses data.' } });
}

function doPost(e) {
  let out;
  try {
    const body = e && e.postData && e.postData.contents ? e.postData.contents : '{}';
    let req;
    try { req = JSON.parse(body); } catch (x) { throw new AppError('BAD_REQUEST', 'Format permintaan tidak valid.'); }
    checkKey_(req.key);
    out = { ok: true, data: route_(String(req.action || ''), req.payload || {}) };
  } catch (err) {
    if (!err.code) console.error(err && err.stack ? err.stack : err);
    out = { ok: false, code: err.code || 'SERVER', error: err.message || String(err) };
  }
  return json_(out);
}

function route_(action, p) {
  switch (action) {
    case 'ping':        return { app: APP.name, version: APP.version, spreadsheet: ss_().getName() };
    case 'list':        return withLock_(() => listAll_());
    case 'add':         return withLock_(() => addTx_(p.tx));
    case 'update':      return withLock_(() => updateTx_(p.tx));
    case 'delete':      return withLock_(() => deleteTx_(p.id, p.type));
    case 'addCategory': return withLock_(() => addCategory_(p));
    default: throw new AppError('BAD_REQUEST', 'Aksi tidak dikenal: ' + action);
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ================================================================
 *  KEAMANAN
 * ================================================================ */

function normKey_(k) { return String(k || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }

function checkKey_(key) {
  const saved = PropertiesService.getScriptProperties().getProperty('APP_KEY');
  if (!saved) throw new AppError('SETUP', 'Backend belum di-setup. Jalankan fungsi setup() di editor Apps Script.');
  const given = normKey_(key);
  if (!given || given !== normKey_(saved)) throw new AppError('AUTH', 'Kunci akses salah.');
}

function generateKey_() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // tanpa huruf/angka yang mirip (O/0, I/1)
  const hex = (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '');
  let key = '';
  for (let i = 0; i < 24; i++) key += chars[parseInt(hex.substr(i * 2, 2), 16) % 32];
  return key.match(/.{4}/g).join('-');
}

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(25000)) throw new AppError('BUSY', 'Server sedang sibuk, coba lagi sebentar.');
  try { const r = fn(); SpreadsheetApp.flush(); return r; }
  finally { lock.releaseLock(); }
}

/* ================================================================
 *  SPREADSHEET & PEMETAAN KOLOM
 * ================================================================ */

let SS_CACHE = null;
const MAP_CACHE = {};

function ss_() {
  if (SS_CACHE) return SS_CACHE;
  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  SS_CACHE = id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
  if (!SS_CACHE) throw new AppError('SETUP', 'Spreadsheet tidak ditemukan. Jalankan setup() dari Apps Script milik spreadsheet-mu.');
  return SS_CACHE;
}

function findSheet_(name) {
  const want = name.toLowerCase().trim();
  return ss_().getSheets().filter(s => s.getName().toLowerCase().trim() === want)[0] || null;
}

function txSheet_(type) {
  if (type !== 'pemasukan' && type !== 'pengeluaran') throw new AppError('VALIDATION', 'Jenis transaksi tidak valid.');
  const sh = findSheet_(SHEETS[type]);
  if (!sh) throw new AppError('SETUP', 'Sheet "' + SHEETS[type] + '" tidak ditemukan di spreadsheet.');
  return sh;
}

function normHeader_(s) {
  return String(s == null ? '' : s).toLowerCase()
    .replace(/\(.*?\)/g, ' ')        // "Nominal (Rp)" → "nominal"
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

/** Mencocokkan satu baris judul dengan kolom-kolom aplikasi. Hasil: {field: nomorKolom(1-based)} */
function matchHeaders_(row) {
  const normed = row.map(normHeader_);
  const used = {};
  const cols = {};
  const pass = test => FIELDS.forEach(f => {
    if (cols[f]) return;
    for (let a = 0; a < ALIASES[f].length; a++) {
      const alias = ALIASES[f][a];
      const i = normed.findIndex((h, idx) => h && !used[idx] && test(h, alias));
      if (i >= 0) { cols[f] = i + 1; used[i] = true; return; }
    }
  });
  pass((h, a) => h === a);                                          // cocok persis
  pass((h, a) => (' ' + h + ' ').indexOf(' ' + a + ' ') >= 0);      // mengandung kata
  return cols;
}

/**
 * Membaca struktur sheet: baris judul + posisi kolom.
 * Kolom yang belum ada (Kategori/Catatan/Metode/ID) ditambahkan di sebelah KANAN
 * tanpa menyentuh kolom & data yang sudah ada.
 */
function getMap_(sh) {
  const key = sh.getSheetId();
  if (MAP_CACHE[key]) return MAP_CACHE[key];

  const lastRow = sh.getLastRow();
  const added = [];
  let headerRow = 0, cols = null;

  if (lastRow === 0) {
    // Sheet kosong → tulis judul kolom standar
    const headers = FIELDS.map(f => LABELS[f]);
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
    sh.hideColumns(FIELDS.indexOf('id') + 1);
    headerRow = 1;
    cols = {};
    FIELDS.forEach((f, i) => { cols[f] = i + 1; });
    added.push.apply(added, headers);
  } else {
    const scan = Math.min(lastRow, 15);
    const vals = sh.getRange(1, 1, scan, Math.max(sh.getLastColumn(), 1)).getDisplayValues();
    for (let r = 0; r < scan; r++) {
      const m = matchHeaders_(vals[r]);
      if (m.tanggal && m.nominal) { headerRow = r + 1; cols = m; break; }
    }
    if (!headerRow) {
      throw new AppError('HEADER', 'Judul kolom di sheet "' + sh.getName() +
        '" tidak dikenali. Pastikan ada kolom "Tanggal" dan "Nominal" (atau "Jumlah").');
    }
    let next = sh.getLastColumn() + 1;
    ['kategori', 'catatan', 'metode', 'id'].forEach(f => {
      if (cols[f]) return;
      if (next > sh.getMaxColumns()) sh.insertColumnsAfter(sh.getMaxColumns(), 1);
      sh.getRange(headerRow, next).setValue(LABELS[f]).setFontWeight('bold');
      if (f === 'id') sh.hideColumns(next);
      added.push(LABELS[f]);
      cols[f] = next++;
    });
  }

  // Lebar tabel = kolom judul terakhir yang terisi (kolom di luar ini tidak pernah disentuh)
  const hdr = sh.getRange(headerRow, 1, 1, sh.getLastColumn()).getDisplayValues()[0];
  let width = 0;
  hdr.forEach((h, i) => { if (String(h).trim()) width = i + 1; });
  FIELDS.forEach(f => { width = Math.max(width, cols[f]); });

  const map = { headerRow: headerRow, cols: cols, width: width, added: added, headers: hdr.slice(0, width) };
  map.sign = amountSign_(sh, map);
  MAP_CACHE[key] = map;
  return map;
}

/** Deteksi kebiasaan: apakah nominal di sheet ini ditulis negatif (mis. -50000)? */
function amountSign_(sh, map) {
  const last = sh.getLastRow();
  if (last <= map.headerRow) return 1;
  const start = Math.max(map.headerRow + 1, last - 29);
  const vals = sh.getRange(start, map.cols.nominal, last - start + 1, 1).getValues();
  let neg = 0, pos = 0;
  vals.forEach(r => { const n = parseAmount_(r[0]); if (n === null || n === 0) return; if (n < 0) neg++; else pos++; });
  return neg > pos ? -1 : 1;
}

/** Baris terakhir yang berisi data (berdasarkan kolom Tanggal / Nominal). */
function lastDataRow_(sh, map) {
  const last = sh.getLastRow();
  if (last <= map.headerRow) return map.headerRow;
  const n = last - map.headerRow;
  const d = sh.getRange(map.headerRow + 1, map.cols.tanggal, n, 1).getValues();
  const a = sh.getRange(map.headerRow + 1, map.cols.nominal, n, 1).getValues();
  for (let i = n - 1; i >= 0; i--) {
    if (!isBlank_(d[i][0]) || !isBlank_(a[i][0])) return map.headerRow + 1 + i;
  }
  return map.headerRow;
}

function findRow_(sh, map, id) {
  const last = sh.getLastRow();
  if (last <= map.headerRow || !id) return -1;
  const ids = sh.getRange(map.headerRow + 1, map.cols.id, last - map.headerRow, 1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]).trim() === id) return map.headerRow + 1 + i;
  return -1;
}

function locate_(id, typeHint) {
  const order = typeHint === 'pemasukan' ? ['pemasukan', 'pengeluaran'] : ['pengeluaran', 'pemasukan'];
  for (let i = 0; i < order.length; i++) {
    const sh = txSheet_(order[i]);
    const map = getMap_(sh);
    const row = findRow_(sh, map, id);
    if (row > 0) return { type: order[i], sheet: sh, map: map, row: row };
  }
  return null;
}

/* ================================================================
 *  BACA DATA
 * ================================================================ */

function listAll_() {
  const a = readTx_('pemasukan');
  const b = readTx_('pengeluaran');
  return {
    transactions: a.list.concat(b.list),
    skipped: a.skipped + b.skipped,
    categories: readCategories_(),
    spreadsheet: ss_().getName(),
    serverTime: new Date().toISOString()
  };
}

function readTx_(type) {
  const sh = txSheet_(type);
  const map = getMap_(sh);
  const c = map.cols;
  const out = [];
  let skipped = 0;
  const last = sh.getLastRow();
  if (last <= map.headerRow) return { list: out, skipped: 0 };

  const n = last - map.headerRow;
  const values = sh.getRange(map.headerRow + 1, 1, n, map.width).getValues();
  const tz = ss_().getSpreadsheetTimeZone();
  const idCol = [];
  let needIds = false;

  for (let i = 0; i < n; i++) {
    const row = values[i];
    const rawId = row[c.id - 1];
    const rawDate = row[c.tanggal - 1];
    const rawAmt = row[c.nominal - 1];
    if (isBlank_(rawDate) && isBlank_(rawAmt)) { idCol.push([rawId]); continue; }   // baris kosong

    const date = parseDate_(rawDate, tz);
    const amount = parseAmount_(rawAmt);
    if (!date || amount === null) { skipped++; idCol.push([rawId]); continue; }    // baris tidak valid (mis. baris TOTAL)

    let id = String(rawId == null ? '' : rawId).trim();
    if (!id) { id = newId_(); needIds = true; }
    idCol.push([id]);
    out.push({
      id: id, type: type, date: date, amount: Math.abs(amount),
      category: str_(row[c.kategori - 1], tz),
      note: str_(row[c.catatan - 1], tz),
      method: str_(row[c.metode - 1], tz),
      seq: map.headerRow + 1 + i
    });
  }
  // Beri ID untuk data lama (hanya mengisi kolom ID yang kosong; isi kolom lain tidak berubah)
  if (needIds) sh.getRange(map.headerRow + 1, c.id, n, 1).setValues(idCol);
  return { list: out, skipped: skipped };
}

/* ================================================================
 *  TULIS DATA
 * ================================================================ */

function validateTx_(tx) {
  if (!tx || typeof tx !== 'object') throw new AppError('VALIDATION', 'Data transaksi kosong.');
  if (tx.type !== 'pemasukan' && tx.type !== 'pengeluaran') throw new AppError('VALIDATION', 'Jenis transaksi tidak valid.');
  const amount = Number(tx.amount);
  if (!isFinite(amount) || amount <= 0) throw new AppError('VALIDATION', 'Nominal harus lebih dari 0.');
  if (amount > 1e13) throw new AppError('VALIDATION', 'Nominal terlalu besar.');
  const date = String(tx.date || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new AppError('VALIDATION', 'Tanggal tidak valid.');
  const category = String(tx.category || '').trim().slice(0, 60);
  if (!category) throw new AppError('VALIDATION', 'Kategori wajib dipilih.');
  const id = String(tx.id || '').trim();
  if (!/^[A-Za-z0-9_-]{6,40}$/.test(id)) throw new AppError('VALIDATION', 'ID transaksi tidak valid.');
  return {
    id: id, type: tx.type, date: date, category: category,
    amount: Math.round(amount * 100) / 100,
    note: String(tx.note || '').trim().slice(0, 200),
    method: String(tx.method || '').trim().slice(0, 40)
  };
}

function addTx_(raw) {
  const tx = validateTx_(raw);
  const sh = txSheet_(tx.type);
  const map = getMap_(sh);
  if (findRow_(sh, map, tx.id) > 0) return { id: tx.id, duplicate: true };   // aman jika terkirim dua kali

  const last = lastDataRow_(sh, map);
  const row = last + 1;
  if (row > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), 1);
  if (last > map.headerRow) copyRowStyle_(sh, map, last, row);
  else {
    sh.getRange(row, map.cols.tanggal).setNumberFormat('dd/mm/yyyy');
    sh.getRange(row, map.cols.nominal).setNumberFormat('"Rp" #,##0');
  }
  writeTx_(sh, map, row, tx);
  return { id: tx.id, row: row };
}

/** Salin format (dan rumus di kolom yang tidak diisi aplikasi) dari baris sebelumnya. */
function copyRowStyle_(sh, map, from, to) {
  const src = sh.getRange(from, 1, 1, map.width);
  const dst = sh.getRange(to, 1, 1, map.width);
  src.copyTo(dst, SpreadsheetApp.CopyPasteType.PASTE_FORMAT, false);
  const mapped = FIELDS.map(f => map.cols[f]);
  const formulas = src.getFormulasR1C1()[0];
  const current = dst.getValues()[0];
  formulas.forEach((fx, i) => {
    if (fx && mapped.indexOf(i + 1) < 0 && isBlank_(current[i])) sh.getRange(to, i + 1).setFormulaR1C1(fx);
  });
}

function writeTx_(sh, map, row, tx) {
  const c = map.cols;
  const tz = ss_().getSpreadsheetTimeZone();
  const put = (col, v) => sh.getRange(row, col).setValue(v);
  put(c.tanggal, Utilities.parseDate(tx.date, tz, 'yyyy-MM-dd'));
  put(c.kategori, safeText_(tx.category));
  put(c.nominal, map.sign * tx.amount);
  put(c.catatan, safeText_(tx.note));
  put(c.metode, safeText_(tx.method));
  put(c.id, tx.id);
}

function updateTx_(raw) {
  const tx = validateTx_(raw);
  const loc = locate_(tx.id, tx.type);
  if (!loc) throw new AppError('NOT_FOUND', 'Transaksi tidak ditemukan di spreadsheet (mungkin sudah dihapus).');
  if (loc.type === tx.type) {
    writeTx_(loc.sheet, loc.map, loc.row, tx);
    return { id: tx.id, row: loc.row };
  }
  // Jenis berubah (mis. pengeluaran → pemasukan): arsipkan baris lama, pindahkan ke sheet baru
  archiveRow_(loc, 'Dipindah ke ' + SHEETS[tx.type]);
  removeRow_(loc);
  return addTx_(tx);
}

function deleteTx_(id, typeHint) {
  id = String(id || '').trim();
  if (!id) throw new AppError('VALIDATION', 'ID transaksi kosong.');
  const loc = locate_(id, typeHint);
  if (!loc) return { id: id, alreadyDeleted: true };
  archiveRow_(loc, 'Dihapus dari aplikasi');
  removeRow_(loc);
  return { id: id, archived: true };
}

function removeRow_(loc) {
  try { loc.sheet.deleteRow(loc.row); }
  catch (e) { loc.sheet.getRange(loc.row, 1, 1, loc.map.width).clearContent(); } // jika tidak boleh hapus baris terakhir
}

/* ================================================================
 *  ARSIP & KATEGORI
 * ================================================================ */

function archiveSheet_() {
  let sh = findSheet_(SHEETS.arsip);
  if (!sh) {
    sh = ss_().insertSheet(SHEETS.arsip);
    const h = ['Waktu Hapus', 'Alasan', 'Jenis', 'Tanggal', 'Kategori', 'Nominal', 'Catatan', 'Metode', 'ID', 'Data Asli (semua kolom)'];
    sh.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function archiveRow_(loc, reason) {
  const map = loc.map, c = map.cols;
  const range = loc.sheet.getRange(loc.row, 1, 1, map.width);
  const vals = range.getValues()[0];
  const disp = range.getDisplayValues()[0];
  const original = {};
  map.headers.forEach((h, i) => { original[String(h).trim() || ('Kolom ' + (i + 1))] = disp[i]; });
  const safe = v => (typeof v === 'string' ? safeText_(v) : v);
  archiveSheet_().appendRow([
    new Date(), reason, SHEETS[loc.type],
    vals[c.tanggal - 1], safe(vals[c.kategori - 1]), vals[c.nominal - 1],
    safe(vals[c.catatan - 1]), safe(vals[c.metode - 1]), safe(vals[c.id - 1]),
    safeText_(JSON.stringify(original))
  ]);
}

function categorySheet_() {
  let sh = findSheet_(SHEETS.kategori);
  if (!sh) {
    sh = ss_().insertSheet(SHEETS.kategori);
    sh.getRange(1, 1, 1, 3).setValues([['Jenis', 'Nama', 'Ikon']]).setFontWeight('bold');
    sh.setFrozenRows(1);
    sh.getRange(2, 1, DEFAULT_CATEGORIES.length, 3).setValues(DEFAULT_CATEGORIES);
  }
  return sh;
}

function readCategories_() {
  const sh = categorySheet_();
  const out = { pemasukan: [], pengeluaran: [], metode: [] };
  const last = sh.getLastRow();
  if (last < 2) return out;
  sh.getRange(2, 1, last - 1, 3).getDisplayValues().forEach(r => {
    const t = normHeader_(r[0]);
    const name = String(r[1]).trim();
    if (!name) return;
    const k = t.indexOf('masuk') >= 0 ? 'pemasukan' : t.indexOf('luar') >= 0 ? 'pengeluaran' : t.indexOf('metode') >= 0 ? 'metode' : null;
    if (k && !out[k].some(x => x.name.toLowerCase() === name.toLowerCase())) out[k].push({ name: name, icon: String(r[2] || '').trim() });
  });
  return out;
}

function addCategory_(p) {
  const type = p && p.type;
  const name = String((p && p.name) || '').trim().slice(0, 40);
  const icon = String((p && p.icon) || '').trim().slice(0, 8);
  if (['pemasukan', 'pengeluaran', 'metode'].indexOf(type) < 0) throw new AppError('VALIDATION', 'Jenis kategori tidak valid.');
  if (!name) throw new AppError('VALIDATION', 'Nama kategori wajib diisi.');
  const cats = readCategories_();
  if (cats[type].some(x => x.name.toLowerCase() === name.toLowerCase())) return { exists: true };
  const label = type === 'pemasukan' ? 'Pemasukan' : type === 'pengeluaran' ? 'Pengeluaran' : 'Metode';
  categorySheet_().appendRow([label, safeText_(name), icon]);
  return { added: true };
}

/* ================================================================
 *  UTILITAS
 * ================================================================ */

function isBlank_(v) { return v === '' || v === null || v === undefined || (typeof v === 'string' && v.trim() === ''); }

function str_(v, tz) {
  if (v instanceof Date) return Utilities.formatDate(v, tz, 'dd/MM/yyyy');
  return isBlank_(v) ? '' : String(v).trim();
}

/** Cegah teks dibaca sebagai rumus (keamanan: =, +, -, @ di awal). */
function safeText_(s) {
  s = String(s == null ? '' : s);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function newId_() { return 'S' + Utilities.getUuid().replace(/-/g, '').slice(0, 15); }

function pad2_(n) { return (n < 10 ? '0' : '') + n; }

function ymd_(y, m, d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 1900 || y > 2200) return null;
  return y + '-' + pad2_(m) + '-' + pad2_(d);
}

const MONTHS_ = {
  jan: 1, januari: 1, january: 1, feb: 2, februari: 2, february: 2, mar: 3, maret: 3, march: 3,
  apr: 4, april: 4, mei: 5, may: 5, jun: 6, juni: 6, june: 6, jul: 7, juli: 7, july: 7,
  agu: 8, ags: 8, agt: 8, agustus: 8, aug: 8, august: 8, sep: 9, sept: 9, september: 9,
  okt: 10, oct: 10, oktober: 10, october: 10, nov: 11, nop: 11, november: 11, des: 12, dec: 12, desember: 12, december: 12
};

/** Mengubah berbagai format tanggal menjadi "yyyy-MM-dd". */
function parseDate_(v, tz) {
  if (v instanceof Date) return isNaN(v.getTime()) ? null : Utilities.formatDate(v, tz, 'yyyy-MM-dd');
  if (typeof v === 'number') {
    if (v > 20000 && v < 80000) return Utilities.formatDate(new Date(Math.round((v - 25569) * 864e5)), 'UTC', 'yyyy-MM-dd');
    return null;
  }
  const s = String(v || '').trim().toLowerCase();
  if (!s) return null;
  let m;
  if ((m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/))) return ymd_(+m[1], +m[2], +m[3]);
  if ((m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{2,4})/))) return ymd_(+m[3], +m[2], +m[1]);   // dd/mm/yyyy
  if ((m = s.match(/(\d{1,2})[\s-]+([a-z]+)\.?[\s-]+(\d{2,4})/)) && MONTHS_[m[2]]) return ymd_(+m[3], MONTHS_[m[2]], +m[1]);
  return null;
}

/** Mengubah "Rp 1.250.000", "1250000", "-50.000", "(50.000)" menjadi angka. */
function parseAmount_(v) {
  if (typeof v === 'number') return isFinite(v) ? v : null;
  if (isBlank_(v)) return null;
  let s = String(v).toLowerCase().replace(/rp|idr/g, '').replace(/\s/g, '');
  const neg = /^-/.test(s) || /^\(.*\)$/.test(s);
  s = s.replace(/[^0-9.,]/g, '');
  if (!s) return null;
  if (/,\d{1,2}$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');                 // 1.250,50
  else if (/^\d+\.\d{1,2}$/.test(s)) { /* desimal titik: 12.5 */ }
  else s = s.replace(/[.,]/g, '');                                                     // 1.250.000 / 1,250,000
  const n = parseFloat(s);
  return isNaN(n) ? null : (neg ? -n : n);
}

/* ================================================================
 *  MENU & SETUP (dijalankan dari editor / menu spreadsheet)
 * ================================================================ */

function onOpen() {
  SpreadsheetApp.getUi().createMenu('💰 Dompetku')
    .addItem('Setup / cek struktur sheet', 'setup')
    .addItem('Lihat kunci akses', 'showKey')
    .addItem('Buat kunci akses baru', 'resetKey')
    .addToUi();
}

/** Jalankan SEKALI setelah menempel kode. Aman dijalankan ulang kapan saja. */
function setup() {
  const props = PropertiesService.getScriptProperties();
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) props.setProperty('SPREADSHEET_ID', active.getId());
  if (!props.getProperty('APP_KEY')) props.setProperty('APP_KEY', generateKey_());

  const lines = [];
  withLock_(() => {
    ['pemasukan', 'pengeluaran'].forEach(t => {
      const sh = txSheet_(t);
      const map = getMap_(sh);
      const r = readTx_(t);
      const detected = FIELDS.map(f => LABELS[f] + ' → kolom ' + colLetter_(map.cols[f])).join(', ');
      lines.push('• ' + SHEETS[t] + ': ' + r.list.length + ' transaksi terbaca' +
        (r.skipped ? ' (' + r.skipped + ' baris dilewati karena tanggal/nominal tidak terbaca)' : '') + '.\n   ' + detected +
        (map.added.length ? '\n   Kolom baru ditambahkan: ' + map.added.join(', ') : ''));
    });
    archiveSheet_();
    categorySheet_();
  });
  notify_('✅ Setup Dompetku berhasil',
    lines.join('\n\n') + '\n\nKunci akses: ' + props.getProperty('APP_KEY') +
    '\n\nLangkah berikutnya: Deploy → Deployment baru → Aplikasi web (Jalankan sebagai: Saya, Akses: Siapa saja).');
}

function showKey() {
  const k = PropertiesService.getScriptProperties().getProperty('APP_KEY');
  notify_('🔑 Kunci akses Dompetku', k ? k + '\n\nMasukkan kunci ini di aplikasi (Pengaturan → Koneksi). Jangan bagikan ke siapa pun.' : 'Belum ada. Jalankan "Setup" dulu.');
}

function resetKey() {
  const k = generateKey_();
  PropertiesService.getScriptProperties().setProperty('APP_KEY', k);
  notify_('🔑 Kunci akses baru dibuat', k + '\n\nKunci lama sudah tidak berlaku. Masukkan kunci baru ini di aplikasi di HP.');
}

function colLetter_(n) { let s = ''; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }

function notify_(title, msg) {
  console.log(title + '\n\n' + msg);
  try { SpreadsheetApp.getUi().alert(title, msg, SpreadsheetApp.getUi().ButtonSet.OK); } catch (e) { /* dijalankan dari editor: lihat Log eksekusi */ }
}
